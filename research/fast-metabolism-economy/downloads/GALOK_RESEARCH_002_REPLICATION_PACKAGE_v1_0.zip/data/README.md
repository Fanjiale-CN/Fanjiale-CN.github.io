# GALOK RESEARCH 002 — Web chart data v1.0

These files are the production data contract for the English web version.

- `headline.json` — Figure 1 headline metrics.
- `final-issuer-system-pool.json` — observation-level pooled source data.
- `quadrants.json` — Figure 3 scatter data; N=20; median MMR=29.1%.
- `brand-lifecycle.json` — Figure 4 category totals and retention metrics.
- `franchise-association.json` — Figure 5 actual N=22 scatter observations.
- `brand-anatomy.json` — Figure 6 card metrics.
- `closure-taxonomy.json` — Figure 7 semantic tree.

Do not hard-code headline numbers in page HTML. Render them from these files.
