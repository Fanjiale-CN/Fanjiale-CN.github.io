# GALOK RESEARCH 002 — Manuscript Architecture v1.0

## Working title

**The Fast Metabolism Economy: Franchising, Network Expansion, and Store Turnover in China’s Consumer Economy**

### Scope note
The empirical center of gravity is chain foodservice and freshly made beverages. The broader phrase “consumer economy” remains defensible only if the manuscript consistently presents foodservice as the principal empirical window rather than a population-representative sample of all Chinese consumer businesses. Before final submission, the title should be stress-tested against a narrower alternative:

**The Fast Metabolism Economy: Franchising, Network Expansion, and Store Turnover in China’s Chain Foodservice Sector**

No title change is authorized automatically at this stage.

---

## Core research object

The paper studies the gap between **net network growth** and the **gross opening-and-closure flows hidden behind that net change**.

The central descriptive metric is the project-defined **Market Metabolism Rate (MMR)**:

\[
MMR_t = \frac{Openings_t + Closures_t}{(Stock_{t-1}+Stock_t)/2}
\]

The main comparison is:

\[
NetGrowth_t = \frac{Openings_t - Closures_t}{Stock_{t-1}}
\]

MMR is a measure of turnover intensity inside a network. It is not a mortality rate, survival probability, failure rate, or claim about economic welfare.

---

## Revised research questions

### RQ1 — Gross turnover
How much store opening-and-closure activity is hidden behind the net growth of large Chinese chain systems?

### RQ2 — Heterogeneous growth states
Do chains with similar net growth exhibit materially different levels of internal turnover, and can observed chain-years be separated into expansion/contraction × high/low-metabolism states?

### RQ3 — Franchising and subsequent expansion
Is greater franchise intensity associated with faster subsequent network growth after accounting for initial network scale?

### RQ4 — Event semantics
How often do common administrative and franchise events—license expiry, entity cancellation, franchisee termination, store transfer, relocation, ranking exit—fail to identify a verified physical store closure?

### RQ5 — Organizational interpretation
What do gross store flows reveal about network restructuring that year-end stock counts and net-new-store reporting suppress?

The earlier outlet-survival, same-brand density, and reputation-shock questions are removed from the empirical core because the final administrative data do not meet the event-history gate required for those models.

---

## Claim hierarchy

### Tier 1 — Headline claims
Supported directly by the frozen issuer-disclosure sample.

1. Net network growth can coexist with substantial gross store turnover.
2. In the strict final-issuer pooled sample, stock-weighted MMR is **25.2%**, compared with **17.3%** stock-weighted net growth.
3. The source-quality extended estimate is **32.5% MMR** and is reported only as a robustness result.
4. Gross-flow states vary substantially across chain-years; growth and metabolism are empirically distinct dimensions.

### Tier 2 — Exploratory association claims
Supported with explicit qualification.

1. The matched franchise-intensity sample does not show a stable positive relationship between franchise intensity and subsequent network growth once initial size is accounted for.
2. The preferred size-adjusted diagnostic is a partial correlation of approximately **−0.058**.
3. The association sample is small (N=22), heavily concentrated at franchise shares above 90%, and unsuitable for causal interpretation.

### Tier 3 — Measurement claims
Supported by issuer disclosures and multi-city administrative audits.

1. Franchisee termination is not equivalent to store closure.
2. Legal-entity exit is not automatically a physical outlet exit.
3. License issue, expiry, renewal, cancellation, and relocation require separate coding.
4. Ranking disappearance is list-composition change and cannot be coded as brand death.

### Tier 4 — Discussion-only propositions
No causal claim is authorized.

- Fast commercial metabolism may accelerate resource reallocation toward organizational forms that can repeatedly absorb locations, franchise capital, traffic, and supply-chain capacity.
- The relationship between commercial metabolism and K-shaped consumption / middle-market hollowing is a hypothesis for discussion and future research, not a result established by R002.

---

## Manuscript structure

### 1. Introduction
Open with the empirical puzzle, not a generic macroeconomic preamble. Use Guming 2025 as the concrete demonstration: 9,914 beginning stores, 4,292 openings, 652 closures, 13,554 ending stores. Net growth was 36.7%; MMR was 42.1%.

Then widen the lens. The 2026 CCFA–Meituan white paper reports roughly 7.47 million operating restaurant merchants at end-2025, almost unchanged year on year, while 3.39 million merchants were marked as having ceased operations during the year. Treat “marked closed” as a platform status, not verified physical death. This tension motivates the paper’s measurement problem.

Bridge to the gross-flow literature (Davis & Haltiwanger; Foster, Haltiwanger & Krizan), then to franchising and turnover/failure literature (Shane; Kosová & Lafontaine; Holmberg & Morgan).

End with the paper’s empirical design, headline findings, and claim boundary.

### 2. Literature and conceptual framework
Organize around four conversations rather than author-by-author summaries:

1. Gross flows, reallocation, and the limits of net aggregates.
2. Retail restructuring, chain expansion, and organizational selection.
3. Franchising as a growth architecture: agency, resource constraints, ownership mix, and survival.
4. Turnover, failure, transfer, and the problem of event definition.

Organizational ecology is used as a conceptual bridge for selection and turnover, not as a biological analogy presented as evidence.

### 3. Data
Three empirical layers:

1. **National roster panel:** 186 canonical brands, 400 brand-year list-presence observations, 2022–2025.
2. **Issuer gross-flow panel:** 24 complete gross-flow observations; strict headline pool of 5 system-years from 4 systems; acquisition and parent-child rules frozen in advance.
3. **Administrative measurement layer:** Beijing, Chengdu, Hangzhou, Shenzhen, Xi’an. More than 8.3 million raw administrative records were processed across downloaded files, but this number is a data-engineering volume, not a count of unique stores, firms, or events.

### 4. Measurement and identification discipline
Define MMR, lag-stock robustness, net growth, closure share, franchise intensity, and roster persistence.

Lock event taxonomy and explain why physical flow, governance conversion, acquisition, franchisee transfer, legal exit, and ranking exit are separate objects.

Explain why survival models were rejected after the city-data gate failed. This is a methodological result, not an omitted-analysis embarrassment.

### 5. Results
Recommended order:

1. Net growth versus gross metabolism.
2. Chain-year heterogeneity and metabolism quadrants.
3. Deep chain anatomy: Guming, MIXUE, Auntea Jenny, ChaPanda, Yum China, Jiumaojiu, Xiabuxiabu.
4. National roster persistence and list turnover.
5. Franchise-intensity association and size confounding.

### 6. Administrative evidence: what counts as a closure?
Use the city audits as a measurement section rather than a failed causal-results section.

- Beijing: clean license IDs, repeated license/address spells, partial entity exports.
- Chengdu: useful status/migration semantics, capped historical slices, no food-license layer.
- Hangzhou: 5 million raw change rows collapse to 821,187 exact-unique records; no readable change date/item; limited authority coverage.
- Shenzhen: 10k license sample contains issuance only; 0.93% high/medium linkage to the capped individual-business sample; store panel fails.
- Xi’an: narrow monthly district evidence only.

### 7. Discussion
Discuss what high turnover can mean without assigning welfare signs mechanically. High metabolism can reflect healthy expansion, deliberate network optimization, weak-store replacement, franchisee turnover, or unstable expansion.

A short subsection may explore the “obese but muscle-weak” / K-shaped-consumption intuition as an explicitly speculative extension: aggregate size can increase while the composition and resilience of the underlying commercial tissue deteriorate. Keep the metaphor out of the headline empirical claims.

### 8. Conclusion
Return to stock versus flow. End with the measurement lesson: a chain’s year-end size tells us where the network finished; gross flows tell us how much of the network had to be rebuilt on the way there.

---

## Writing rules — locked

- Final manuscript language: English.
- No “In recent years…” opening.
- No “Against this backdrop…” filler.
- No automatic “This paper makes three contributions…” paragraph.
- No mechanical “First, Second, Third” scaffolding unless genuinely needed.
- No policy-report tone, investor-report tone, or press-release adjectives.
- Numbers appear only when their denominator and sample meaning are clear.
- Company language such as “high-quality growth” is quoted or attributed, never adopted as the paper’s voice.
- A null/weak result remains a result. Franchise-intensity evidence will not be forced into a positive story.
- Failed data gates remain visible. They discipline interpretation.
- Metaphors may clarify the argument in the web essay or Discussion, but they never substitute for measurement.
- Every claim must survive the question: “What exact observation would make this sentence true?”

---

## Current writing authorization

**NATIONAL_CORE_FROZEN**

**CITY_SEMANTICS_AUDITED**

**STORE_SURVIVAL_BRANCH = REJECTED BY DATA GATE**

**FULL_MANUSCRIPT_WRITING = AUTHORIZED**
