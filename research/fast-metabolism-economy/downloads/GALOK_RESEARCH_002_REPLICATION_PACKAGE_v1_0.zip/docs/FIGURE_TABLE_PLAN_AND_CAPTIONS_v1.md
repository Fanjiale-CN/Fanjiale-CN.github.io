# GALOK RESEARCH 002 — Final Figure/Table Plan and Captions v1.0

All final figure text is **English**. PNG prototypes are design references only; publication charts are rebuilt in HTML/CSS/SVG/ECharts/JavaScript from the release JSON/CSV.

## Figure 1 — A growing network can replace a large share of itself
Primary: **17.3% net growth** vs **25.2% MMR** (conservative core). Small secondary note: expanded final-issuer pool **25.5% net growth / 34.5% MMR**.

*Caption:* Net network growth and gross store metabolism measure different margins of chain expansion. The conservative core contains five system-years from four systems; the expanded final-issuer pool contains 13 system-years from eight independent systems.

## Figure 2 — What net growth leaves out: Guming, 2025
`9,914 beginning → +4,292 opened → −652 closed → 13,554 ending`
Net growth **36.7%**; MMR **42.1%**.
Required formula: `MMR = (Openings + Closures) / Average(Beginning stock, Ending stock)`.

## Figure 3 — Growth and metabolism are separate dimensions
Actual scatter only. **N=20**. X = net growth; Y = MMR; vertical line = 0%; horizontal line = **29.1% median MMR**. Fixed-30% agreement **18/20 = 90%**. Selected labels: Guming 2025, Busy Ming 2024/2025, Auntea Jenny 2025, Jiumaojiu 2025, Yum China Other Brands 2025, Xiabuxiabu 2025, MIXUE 2024.

*Caption:* Net growth and MMR form distinct dimensions across 20 full-year, no-acquisition observations. Parent and child observations may appear as separate plotted states but are never pooled together in headline estimates.

## Figure 4 — Roster persistence is not brand survival
186 × 4 presence matrix for 2022–2025. Groups: Persistent core 37; New 2025 entrant 32; Reentry/gapped active 4; Active recent 27; Dropped after 2024 36; Early dropout 50. Retention: 69% → 75% → 64%.

## Figure 5 — Franchise intensity and subsequent growth
Actual N=22 scatter. Statistics strip: Pearson **0.07**; Spearman **0.34**; partial r controlling log initial size **−0.06**. Do not visually make a raw regression line represent the partial result.

## Figure 6 — Different chains, different internal mechanics
Aligned small-multiple cards: Guming 2025; MIXUE 2024; Auntea Jenny 2025; ChaPanda 2025. ChaPanda card highlights **1,218 franchisee terminations / 735 stores transferred**, with `FRANCHISEE EXIT ≠ STORE CLOSURE`.

## Figure 7 — What counts as a closure?
Semantic taxonomy / decision tree. Administrative records, relationship/governance events, spatial/visibility events, and verified physical closure remain separate. Strongest emphasis only on a source-verified physical outcome.

## Core tables
- Table 1: empirical data architecture — issuer panel **26 complete observations** and both pooled rules.
- Table 2: conservative core vs expanded final-issuer pool.
- Table 3: growth–metabolism regimes — **20 observations, median 29.1%, 7/9/3/1**.
- Table 4: roster lifecycle classification — 37/32/4/27/36/50.

## Website data contract
`/data/research-002/headline.json`
`/data/research-002/final-issuer-system-pool.json`
`/data/research-002/quadrants.json`
`/data/research-002/brand-lifecycle.json`
`/data/research-002/franchise-association.json`
`/data/research-002/closure-taxonomy.json`

Headline statistics must be read from data files, not hand-typed separately in page code.
