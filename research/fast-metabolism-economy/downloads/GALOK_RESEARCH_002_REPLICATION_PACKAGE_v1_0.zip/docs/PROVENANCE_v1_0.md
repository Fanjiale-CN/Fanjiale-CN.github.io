# GALOK RESEARCH 002 — PROVENANCE v1.0

**Freeze:** `NATIONAL_ANALYSIS_FREEZE_v1.0`  
**Date:** 2026-08-21

## Canonical workbook

`GALOK_RESEARCH_002_NATIONAL_ANALYSIS_FREEZE_v1_0.xlsx`

The file is an exact copy of the v1.0 freeze candidate after its successful audit. The candidate had zero formula-error matches for `#REF!`, `#DIV/0!`, `#VALUE!`, `#NAME?`, and `#N/A` in the final scan.

## Frozen rules

- gross-flow admission requires beginning stock, openings, closures, ending stock;
- primary MMR uses average beginning/end stock;
- lag-stock MMR is robustness only;
- final issuer group-level FY rows form the strict headline pool;
- draft issuer rows remain sensitivity evidence;
- parent and child network observations cannot be pooled together;
- H1 observations are not annualized;
- acquisition stock breaks are excluded from headline estimates;
- recovered 2019–2021 roster rows remain noncanonical for headline retention;
- ranking exit is never brand death.

## Pending branch

Shenzhen authenticated row access remains the sole external gate before project-level writing authorization and survival-model specification.
