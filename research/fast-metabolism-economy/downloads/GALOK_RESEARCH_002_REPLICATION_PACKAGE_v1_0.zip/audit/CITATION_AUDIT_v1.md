# GALOK RESEARCH 002 — Citation Audit v1.0

## Overall status

**PASS WITH FINAL PRODUCTION CHECKS**

The substantive citation pass prioritizes original issuer filings, peer-reviewed literature, official/public data sources, and named industry reports. The material Busy Ming/Auntea Jenny late-source update is incorporated into the release-candidate manuscript.

## Issuer gross-flow claims

| System | Status | Final source use |
|---|---|---|
| Guming | PASS | 2025 annual report; 2024–2025 flow |
| MIXUE Group | PASS | 2025 annual report; 2024 organic flow and 2025 acquisition-break example |
| ChaPanda | PASS | 2025 annual report; 2024–2025 franchised flow and franchisee transfers |
| Auntea Jenny | PASS | 2025 annual report; 2024–2025 all-brand franchised flow |
| Busy Ming Group | PASS | 2025 annual report; final 2024–2025 flow; old draft sensitivity retired |
| Jiumaojiu | PASS | 2025 annual report |
| Xiabuxiabu Group | PASS | 2025 annual report |
| Yum China | PASS | SEC full-year exhibits for 2024–2025 |

## Academic framework

Verified and retained: Davis & Haltiwanger (1990, 1992); Foster, Haltiwanger & Krizan (2006); Foster, Haltiwanger & Syverson (2008); Foster et al. (2015); Shane (1996); Lafontaine & Shaw (2005); Kosová & Lafontaine (2010); Holmberg & Morgan (2003); Hannan & Freeman (1977); Pe’er & Vertinsky (2008); Wang et al. (2026).

## Consumer-polarization context

Retained as external context rather than causal identification: Bain & Worldpanel 2026; NielsenIQ & World Data Lab 2026; McKinsey 2025; CCFA & Meituan 2026. The phrase “marked as ceased operations” must remain intact for the CCFA/Meituan platform measure.

## Administrative evidence

City claims remain grounded in the final processed public-data audits. The paper must describe the **8.38 million** figure as raw administrative records processed, never unique stores, unique firms, or unique exit events.

## Claim boundaries

- 25.2% and 34.5% are disclosure-sample pooled statistics, not China-wide turnover rates.
- The N=22 franchise exercise is exploratory.
- Ranking exit is not brand death.
- Administrative cancellation is not automatically physical closure.
- K-shaped consumer polarization stays in Discussion.
- No causal statement links MMR to concentration, polarization, or middle-market decline.

## Final production checks

1. Apply one reference style consistently after venue/website format is fixed.
2. Match every final figure/table source note to `FINAL_ISSUER_SYSTEM_POOL_v1_1.json` or the corresponding audited dataset.
3. Add stable replication-package links and access dates where the final format requires them.
