# GALOK RESEARCH 002 — Late-Source and Scope Audit v1.0

## Decision

The previous draft-source sensitivity result of **32.5% MMR** is retired.

The final citation pass located final 2025 annual-report evidence for Busy Ming Group and a comparative 2024–2025 all-brand flow table in Auntea Jenny's 2025 annual report. Busy Ming reports 2024 franchised-store movement of 6,569 + 8,083 − 273 → 14,379 and 2025 movement of 14,379 + 7,813 − 265 → 21,927. Its franchised stores represented 99.9% of the disclosed total network at both year ends. Auntea Jenny reports 2024 all-brand franchised-store movement of 7,756 + 2,383 − 987 → 9,152 and 2025 movement of 9,152 + 3,654 − 1,383 → 11,423. Its franchised scope represented more than 99% of the disclosed total network.

## Updated universe

- Complete gross-flow observations: **26**
- Full-year observations: **22**
- Half-year observations: **4**
- Full-year acquisition-stock breaks: **2**
- Full-year no-acquisition descriptive observations: **20**

## Conservative core

- observations: 5
- systems: 4
- gross flow: 19,248
- combined average stock: 76,413
- MMR: **25.1894%**
- net growth: **17.3324%**
- closure share: **18.3396%**

## Expanded final-issuer pool

- observations: 13
- systems: 8
- gross flow: 55,753
- combined average stock: 161,556.5
- MMR: **34.5099%**
- net growth: **25.5320%**
- closure share: **17.1955%**

The 25.2% conservative benchmark remains visible because its network scopes are maximally uniform. The expanded **34.5% MMR / 25.5% net-growth** result replaces the obsolete 32.5% draft-source sensitivity.

## Updated quadrant

- N = **20**
- median MMR = **29.1166%**
- high metabolism + expansion = **7**
- low metabolism + expansion = **9**
- high metabolism + contraction = **3**
- low metabolism + contraction = **1**
- fixed 30% threshold agreement = **18/20 = 90%**

Figure 3 must use **29.1%** as the median line and **N=20**.

## Primary late-source URLs

- Busy Ming Group Annual Report 2025: https://www1.hkexnews.hk/listedco/listconews/sehk/2026/0429/2026042901204.pdf
- Auntea Jenny Annual Report 2025: https://www.hkexnews.hk/listedco/listconews/sehk/2026/0428/2026042804495.pdf

The original national-freeze workbook is preserved as a historical freeze and is not silently overwritten. This audit and `FINAL_ISSUER_SYSTEM_POOL_v1_1.json` govern the release-candidate manuscript and website data layer.
