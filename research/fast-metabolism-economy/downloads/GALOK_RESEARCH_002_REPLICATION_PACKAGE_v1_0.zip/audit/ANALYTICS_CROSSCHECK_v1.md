# GALOK RESEARCH 002 — Independent Analytics Cross-check v1.0

**Date:** 2026-08-22  
**Input:** `GROSS_FLOW_ANALYSIS_v0_1.csv`, frozen audit files, final city audits  
**Purpose:** independently recompute the numbers allowed to enter the manuscript before prose drafting.

## 1. Strict headline pool

Admission rule:

`final issuer disclosure + group-level + FY + explicit gross openings/closures + no acquisition stock break`

Rows admitted: **5 system-years / 4 unique systems**

- MIXUE Group — 2024
- Jiumaojiu — 2025
- Xiabuxiabu Group — 2025
- Yum China — 2024
- Yum China — 2025

Pooled components:

- Sum gross flow (openings + closures): **19,248**
- Sum average stock: **76,413**
- Sum net change: **12,188**
- Sum beginning stock: **70,319**
- Sum closures: **3,530**

Recomputed headline metrics:

\[
Weighted\ MMR = 19,248 / 76,413 = 0.2518943 = \mathbf{25.1894\%}
\]

\[
Weighted\ NetGrowth = 12,188 / 70,319 = 0.1733244 = \mathbf{17.3324\%}
\]

\[
ClosureShare = 3,530 / 19,248 = 0.1833957 = \mathbf{18.3396\%}
\]

**Rounded manuscript values: 25.2%, 17.3%, 18.3%.**

These reproduce the frozen audit exactly.

## 2. Extended source-quality sensitivity

Adds Busy Ming Group 2022 and 2024, sourced from draft/post-hearing issuer material.

Rows: **7 system-years / 5 systems**

- Sum gross flow: **28,707**
- Sum average stock: **88,247.5**
- Sum net change: **21,073**
- Sum beginning stock: **77,711**
- Sum closures: **3,817**

Recomputed:

- Weighted MMR: **32.5301%**
- Weighted net growth: **27.1171%**
- Closure share: **13.2964%**

The **32.5%** result is robustness only. It is not the primary estimate.

## 3. Chain-level arithmetic checks used in the Introduction

### Guming 2025

- Beginning stock: 9,914
- Openings: 4,292
- Closures: 652
- Ending stock: 13,554
- Identity: `9,914 + 4,292 − 652 = 13,554` — PASS
- Average stock: `(9,914 + 13,554)/2 = 11,734`
- MMR: `(4,292 + 652)/11,734 = 42.13397%`
- Net growth: `(4,292 − 652)/9,914 = 36.71576%`

### MIXUE Group 2024

- Beginning: 37,516
- Openings: 10,555
- Closures: 1,609
- Ending: 46,462
- MMR: **28.9695%**
- Net growth: **23.8458%**

### MIXUE Group 2025

Contains a disclosed **1,354-store acquisition addition** from FULU Fresh Beer. It remains outside the organic headline pool. The acquisition residual matches the stock identity break exactly.

### ChaPanda 2025

- Franchisees terminated: **1,218**
- Of these, **735** transferred their stores to other franchisees for continued operation.
- Closed franchised stores: **933**

This independently demonstrates that franchisee exit and outlet closure are different events.

## 4. Cross-sectional diagnostics

Metabolism quadrants use **18 FY, no-acquisition gross-flow observations**.

- Median MMR threshold: **26.8%**
- High metabolism + expansion: 6
- Low metabolism + expansion: 8
- High metabolism + contraction: 3
- Low metabolism + contraction: 1
- Classification agreement with a fixed 30% threshold: **15/18 = 83.3%**

Franchise-intensity association:

- Matched brands: **N=22**
- Pearson intensity-growth: **0.069**
- Spearman: **0.335**
- Pearson log(initial size)-growth: **0.522**
- Partial correlation intensity-growth controlling log(initial size): **−0.058**

Decision: no stable positive association claim is authorized.

## 5. Administrative data engineering volume

Approximate raw downloaded/admin-row volume processed across the final city workstreams:

- Beijing: **2,454,528** rows across seven downloaded tables
- Chengdu: **23,000** rows across seven capped legacy XLS tables
- Hangzhou: **5,795,532** raw rows across the 5m change corpus plus basic/annual/webshop/license files
- Shenzhen: **110,000** raw rows in the final downloaded samples
- Xi’an: **388** rows in the October 2025 High-Tech Zone files

Combined raw processing volume: **8,383,448 rows**.

This number can be described only as **raw administrative records processed**. It cannot be called 8.38 million unique businesses, stores, or events. Hangzhou alone contains 4,178,813 exact duplicate change rows in the 5m raw corpus.

## 6. Final analytic gates

- National issuer/descriptive core: **PASS / FROZEN**
- Beijing store panel: **PARTIAL**
- Chengdu entity lifecycle: **PARTIAL**; store panel **FAIL**
- Hangzhou: **IDENTITY_AUXILIARY / CHANGE_EVIDENCE_PARTIAL**
- Shenzhen store panel: **FAIL**
- Xi’an: **SUPPLEMENT ONLY**
- KM / Cox / AFT: **NOT AUTHORIZED**
- Local same-brand density / cannibalization: **NOT AUTHORIZED**

The rejected survival branch does not alter the strict pooled MMR calculation or the national/deep-chain descriptive findings.
