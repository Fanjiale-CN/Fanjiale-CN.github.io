# GALOK RESEARCH 002 — Public Replication Package v1.0

This package contains the final English manuscript, derived figure/table data, source and scope audits, and production notes.

## What is included
- Final manuscript (`manuscript/`)
- Figure-ready JSON and README (`data/`)
- Citation, source-scope, analytics, and release audits (`audit/`)
- Figure/table plan and provenance notes (`docs/`)

## What is not included
Raw municipal administrative downloads are not mirrored here. They remain in the private research archive under their original government-platform files and terms.

## Reproducible headline calculations
MMR = (Openings + Closures) / Average(Beginning stock, Ending stock)
Net growth = (Openings − Closures) / Beginning stock
Closure share = Closures / (Openings + Closures)

The JSON files contain the observation-level values needed to reproduce the paper’s pooled figures and web charts.
